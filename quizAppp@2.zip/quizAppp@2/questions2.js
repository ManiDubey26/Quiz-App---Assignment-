// creating an array and passing the number, questions, options, and answers
let questions = [
    {
    numb: 1,
    question: "If P= ₹1000, R=5% p.a, n=4; What Is The Amount and CI",
    answer: "₹1,215.50 , ₹215.50",
    options: [
      "₹1,215.50 , ₹215.50",
      "₹1,125 , ₹125",
      "₹2,115 , ₹1,115",
      "None Of These"
    ]
  },
    {
    numb: 2,
    question: "In how many years will a sum of money double at 5% p.a. compound interest",
    answer: "14years 2 months",
    options: [
      "15years 3 months",
      "14years 2 months",
      "14years 3 months",
      "15years 2 months"
    ]
  },
    {
    numb: 3,
    question: "In how many years a sum of money trebles at 5% p.a. compound interest payable on half-yearly basis?",
    answer: "22years 3 months",
    options: [
      "18years 7 months",
      "18years 6 months",
      "18years 8 months",
      "22years 3 months"
    ]
  },
    {
    numb: 4,
    question: "If A = 1,000, n = 2 years, R = 6% p.a compound interest payable half-yearly, then principal (P) is",
    answer: "₹688.50",
    options: [
        "₹688.50",
        "₹885",
        "₹800",
        "None Of These"
    ]
  },
    {
    numb: 5,
    question: "The C.I on 16000 for 1 ½ years at 10% p.a payable half -yearly is",
    answer: "₹2,522",
    options: [
      "₹2,222",
      "₹2,522",
      "₹2,500",
      "None Of These"
    ]
  },
  // you can uncomment the below codes and make duplicate as more as you want to add question
  // but remember you need to give the numb value serialize like 1,2,3,5,6,7,8,9.....

  //   {
  //   numb: 6,
  //   question: "Your Question is Here",
  //   answer: "Correct answer of the question is here",
  //   options: [
  //     "Option 1",
  //     "option 2",
  //     "option 3",
  //     "option 4"
  //   ]
  // },
];